Recorded replay only. Install requirements, then run python reproduce.py.
Only existing source responses are revealed; no counterfactual or live measurement occurs.
Read LIMITATIONS.txt and retained CC-BY source attribution before interpreting results.
