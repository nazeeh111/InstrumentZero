import json
from pathlib import Path
from instrumentzero.replay import recorded_stiffness_replay
root=Path(__file__).parent
config=json.loads((root/"config.json").read_text())
result=recorded_stiffness_replay(root/"data", **config)
(root/"reproduced-replay.json").write_text(json.dumps(result, indent=2, allow_nan=False)+"\n")
print(json.dumps(result["reference_check"], indent=2))
